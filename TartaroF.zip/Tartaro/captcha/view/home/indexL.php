<a class="brand-logo page-header text-center" href="/Tartaro/indexxx.html"> <h1> <span class="black-text ">Catrines Clika - Login</span> </h1> </a>


<div class="row">
    <div class="col-xs-2"></div>
    <div class="col-xs-8">
        <fieldset>
            <legend class="text-center">"Quid pro quo"</legend>
            
            <form id="frm-comentar" action="?c=Home&a=Procesar" method="post">
            <div class="form-group">
                    <label>Correo</label>
                    <input type="email" id="correo1" name="correo1" placeholder="Marcelin@Catrines.com" required title="Se necesita un correo" class="form-control" name="email"/>
                    <script languaje="javascript">
  				        var cor = new LiveValidation('correo1');
                          cor.add(Validate.Presence, {failureMessage: "Escriba por favor su correo!!!"});
                          cor.add(Validate.email,{failureMessage:"Email incorrecto"});
			        </script>
                </div>
                <div class="form-group">
                    <label>Firma</label>
                    <input type="Text" id="Fir" name="Fir" placeholder="Hiromiya" class="form-control" pattern="[A-Z][a-z][0-9]" required maxlength="10" name="firma"/>
                    <script languaje="javascript">
  				        var fir = new LiveValidation('Fir');
  				        fir.add(Validate.Presence, {failureMessage: "Favor de introducir su firma!!!"});
                        fir.add(Validate.Length,{minimum: 10, maximum: 10});
			        </script>
                </div>
                <div class="form-group">
                    <label>Captcha</label>
                    <input type="text" name="Captcha" placeholder="Per favore use Mayusculas y minusculas" class="form-control" pattern="[A-Z][a-z][0-9]" data-validacion-tipo="requerido|min:5" maxlength="5" />
                </div>
                <div class="thumbnail">
                    <img id="captcha" src="" />
                </div>
                <button id="btn-comentar" class="btn btn-info btn-lg btn-block" type="submit">Enviar</button>                
            </form>
             <button src="/Tartaro/indexxx.html" class="btn btn-lg btn-block">Cancelar</button>
        </fieldset>
    </div>
</div>

<script>
$(document).ready(function(){
    // Cargamos el captcha
    CargaCaptcha();

    $("#frm-comentar").submit(function(){

        var obj = $(this);

        if(obj.validate()) {
           $.post(obj.attr('action'), obj.serialize(), function(r)
           {
                // En caso de que el captcha no sea correcto, volvemos a cargar
                if(!r.respuesta) 
                {
                    CargaCaptcha();
                }
                else 
                {
                    obj.html('<div class="alert alert-info text-center">¡Su comentario ha sido enviado con éxito!</div>');
                }

           }, 'json')                
        }

        return false;
    });
})
        
function CargaCaptcha()
{
    var d = new Date();
    $("#captcha").attr('src', '?c=Captcha&' + d.getTime());
}
</script>