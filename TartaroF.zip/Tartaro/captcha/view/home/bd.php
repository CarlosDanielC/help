<?PHP
$db ="CatrinesClika";
$dbEC ="CatrinesKlica"; 
$pass="";
$servidor="localhost";
$user = "root";
$clave="";


$conexion = mysqli_connect($servidor,$user,$clave, "CatrinesKlica");
if(!$conexion)
 {echo "<h2>Error al establecer conexion con el server</h2>";
   exit;}

   extract($_REQUEST, EXTR_PREFIX_ALL|EXTR_REFS, 'frm');
   echo "DATOS RECIBIDOS CIFRADOS<br />";
   echo "<br />Login: ".$frm_nombre;
   echo "<br />Password: ".$frm_apellido;
   echo "<br />nombre: ".$frm_contraseña;
   echo "<br />Curp: ".$frm_curp;
   echo "<br />Rfc: ".$frm_rfc;
   echo "<br />Direccion: ".$frm_direccion;
   echo "<br />Email: ".$frm_email;
   echo "<br />Firma: ".$frm_clave_publica;
   echo "<br /> ";
   $sql = "INSERT INTO usuarios (nombre,apellidos,contraseña,curp,rfc,direccion,email,firma)values
   ('$frm_login','$frm_password','$frm_nombre','$frm_curp','$frm_rfc','$frm_direccion','$frm_email','$frm_clave_publica')";
   mysqli_query($conexion,$sql);
   echo"DATOS GUARDADOS";

   $sql ="SELECT * FROM firmas WHERE id_firma='1'";
   $resultado= mysqli_query($conexion,$sql);

   if (!$resultado) {
      echo "Error de BD, no se pudo consultar la base de datos\n";
    echo "Error MySQL: ' . mysql_error()";
      exit;
      }

       if ($fila = mysqli_fetch_assoc($resultado)) {
      $claveprivada = $fila['firma'];
      echo $frm_login;
      }


   mysqli_close($conexion);

?>