<a class=" page-header text-center" href="/Tartaro/indexxx.html"> <h1> <span class="black-text ">Catrines Clika</span> </h1> </a>
<div class="row">
    <div class="col-xs-2"></div>
    <div class="col-xs-8">
        <fieldset>
            <legend class="text-center">"Quid pro quo"</legend>
            
            <form id="frm-comentar" action="?c=Home&a=Procesar" method="post">
                <div class="form-group">
                    <label>Nombre</label>
                    <input type="text" id="name1" class="form-control" name="Nombre" placeholder="Adelaida" title="Se necesita un nomnre"ata-validacion-tipo="requerido|min:3" maxlength="15" pattern="[A-Za-z]" />
                    <script languaje="javascript">
  				        var name = new LiveValidation('name1');
  				        name.add(Validate.Presence, {failureMessage: "Escribir por favor un nombre!!!"});
                        name.add(Validate.Length,{minimun: 3, maximum: 25});
                        name.add(Validate.Format,{pattern:/^[a-zA-Z]});
			        </script>
                </div>
                <div class="form-group">
                    <label>Apellido</label>
                    <input type="text" id="lastname1" class="form-control" name="lastname1" placeholder="Perez" title="Se necesita un el apellido" maxlength="15" data-validacion-tipo="requerido|min:5" pattern="[A-Za-z]" />
                    <script languaje="javascript">
  				        var lastname = new LiveValidation('lastname1');
  				        lastname.add(Validate.Presence, {failureMessage: "Escribir por favor su apellido!!!"});
                        lastname.add(Validate.Length,{minimun: 5, maximum: 25});
                        lastname.add(Validate.Format,{pattern:/^[a-zA-Z]});
			        </script>
                </div>
                <div class="form-group">
                    <label>Contraseña</label>
                    <input type="password" id="pass" class="form-control" required maxlength="30" name="pass"/>
                    <script languaje="javascript">
  				        var pa = new LiveValidation('pass');
  				        pa.add(Validate.Presence, {failureMessage: "Favor de introducir una contraseña!!!"});
			        </script>
                </div>
                <div class="form-group">
                    <label>Correo</label>
                    <input type="email" id="correo1" placeholder="Marcelin@Catrines.com" required title="Se necesita un correo" class="form-control" name="email"/>
                    <script languaje="javascript">
  				        var cor = new LiveValidation('correo1');
  				        cor.add(Validate.Presence, {failureMessage: "Escriba por favor su correo!!!"});
                        cor.add(Validate.email,{failureMessage:"Email incorrecto"});
			        </script>
                </div>
                <div class="form-group">
                    <label>Firma</label>
                    <input type="Text" id="Fir" placeholder="Horimiya" class="form-control" pattern="[A-Z][a-z][0-9]" required maxlength="10" name="firma"/>
                    <script languaje="javascript">
  				        var fir = new LiveValidation('Fir');
  				        fir.add(Validate.Presence, {failureMessage: "Favor de introducir su firma!!!"});
			        </script>
                </div>
                <div class="form-group">
                    <label>CURP</label>
                    <input type="Text" id="CURP" placeholder="no se como son esas cosas" class="form-control" pattern="[A-Z][a-z][0-9]" required maxlength="10" name="curp"/>
                    <script languaje="javascript">
  				        var curp = new LiveValidation('CURP');
  				        curp.add(Validate.Presence, {failureMessage: "Favor de introducir su CURP!!!"});
			        </script>
                </div>
                <div class="form-group">
                    <label>Dirección</label>
                    <input type="Text" id="direc" placeholder="Gothica,Avenida Nueva Esperanza #83" class="form-control" pattern="[A-Z][a-z][0-9]" required maxlength="10" name="dire"/>
                    <script languaje="javascript">
  				        var curp = new LiveValidation('CURP');
  				        curp.add(Validate.Presence, {failureMessage: "Favor de introducir su dirección!!!"});
			        </script>
                </div>
                <div class="form-group">
                    <label>RFC</label>
                    <input type="Text" id="rfc" placeholder="HAHAHA, estas tampoco se como son" class="form-control" pattern="[A-Z][a-z][0-9]" required maxlength="10" name="rfc"/>
                    <script languaje="javascript">
  				        var rfc = new LiveValidation('rfc');
  				        rfc.add(Validate.Presence, {failureMessage: "Favor de introducir su rfc!!!"});
			        </script>
                </div>
                <div class="form-group">
                    <label>Captcha</label>
                    <input type="text" name="Captcha" placeholder="Per favore use Mayusculas y minusculas" class="form-control" data-validacion-tipo="requerido|min:5" maxlength="5" />
                </div>
                <div class="thumbnail">
                    <img id="captcha" src="" />
                </div>
                <button id="btn-comentar" name="von" class="btn btn-info btn-lg btn-block" type="submit">Enviar</button>                
            </form>
        </fieldset>
    </div>
</div>

<script>
$(document).ready(function(){
    // Cargamos el captcha
    CargaCaptcha();

    $("#frm-comentar").submit(function(){

        var obj = $(this);

        if(obj.validate()) {
           $.post(obj.attr('action'), obj.serialize(), function(r)
           {
                // En caso de que el captcha no sea correcto, volvemos a cargar
                if(!r.respuesta) 
                {
                    CargaCaptcha();
                }
                else 
                {
                    obj.html('<div class="alert alert-info text-center">¡Usted ha sido registrado con éxito!</div>');
                }

           }, 'json')                
        }

        return false;
    });
})
        
function CargaCaptcha()
{
    var d = new Date();
    $("#captcha").attr('src', '?c=Captcha&' + d.getTime());
}
</script>
<?php 
    include("bd.php");
?>