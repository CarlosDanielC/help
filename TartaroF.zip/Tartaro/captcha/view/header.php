<!DOCTYPE html>
<html lang="es">
	<head>
        <meta charset="utf-8"/>
        <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
        <link rel="stylesheet" href="assets/css/bootstrap-theme.min.css" />
        <link rel="stylesheet" href="assets/js/jquery-ui/jquery-ui.min.css" />
        <link rel="stylesheet" href="assets/js/jquery-ui/jquery-ui.theme.min.css" />
        <link rel="stylesheet" href="assets/css/style.css" />
        <link rel="stylesheet" href="assets/css/materialize.min.css" media="screen,projection">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link type="text/css" rel="stylesheet" href="assets/css/materialize.css">
        <script type="text/javascript" src="https://code.jquery.com/jquery-3.4.1.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
        <style type="text/css" media="all">
            h2, h3 {display: inline;}
        </style>
        <meta charset="utf-8"/>
        <title>Catrines Clika - Login</title>
        <script src="md5-min.js"></script>
        <script type="text/javascript">
            function generar_certificado() {
                var firma = document.getElementById("certificado").value;
                var Login = document.getElementById("login").value;
                var certificado = hex_md5(firma + Login);
                window.alert("Certificado = MD5(Firma+Login): " + certificado);
                document.getElementById("certificado").value=certificado;
                return true;
            }
        </script>
        <script src="http://code.jquery.com/jquery-1.11.2.min.js"></script>
        <script languaje="javascript" src="assets/livevalidation_standalone.compressed.js"></script>
	</head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
