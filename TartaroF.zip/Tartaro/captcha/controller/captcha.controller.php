<?php
require_once 'lib/captcha/captcha.php';
class CaptchaController{
    public function Index()
    {
        Captcha::Mostrar();
    }
}