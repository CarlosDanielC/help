<?php
require_once 'lib/captcha/captcha.php';
class HomeController{
    
    private $model;
    
    public function __CONSTRUCT(){

    }
    
    public function Index(){
        require_once 'view/headerL.php';
        require_once 'view/home/indexL.php';
        require_once 'view/footer.php';
    }

    public function Procesar()
    {
        print_r(json_encode(array('respuesta'=>Captcha::Valida($_POST['Captcha']))));
    }
}