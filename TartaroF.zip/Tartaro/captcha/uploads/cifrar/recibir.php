<!DOCTYPE html>

<html>
	<head>
		<title>Cifrado de datos de un formulario con JavaScript</title>
		<meta charset="utf-8" />
	</head>
	<body>
		<h2>Cifrado de datos de un formulario con JavaScript</h2>
		<?PHP
			
			

			$servidor="localhost";
			$user = "root";
			$clave="";


			$conexion = mysqli_connect($servidor, $user,$clave, "practica12");
			if(!$conexion)
			 {echo "<h2>Error al establecer conexion con el server</h2>";
				exit;}
 
				extract($_REQUEST, EXTR_PREFIX_ALL|EXTR_REFS, 'frm');
				echo "DATOS RECIBIDOS CIFRADOS<br />";
				echo "<br />Login: ".$frm_login;
				echo "<br />Password: ".$frm_password;
				echo "<br />nombre: ".$frm_nombre;
				echo "<br />Curp: ".$frm_curp;
				echo "<br />Rfc: ".$frm_rfc;
				echo "<br />Direccion: ".$frm_direccion;
				echo "<br />Email: ".$frm_email;
				echo "<br />Firma: ".$frm_clave_publica;
				echo "<br /> ";
				$sql = "INSERT INTO datos (login,password,nombre,curp,rfc,direccion,email,id_firma)values
				('$frm_login','$frm_password','$frm_nombre','$frm_curp','$frm_rfc','$frm_direccion','$frm_email','$frm_clave_publica')";
				mysqli_query($conexion,$sql);
				echo"DATOS GUARDADOS";

				$sql ="SELECT * FROM firmas WHERE id_firma='1'";
				$resultado= mysqli_query($conexion,$sql);

				if (!$resultado) {
   				echo "Error de BD, no se pudo consultar la base de datos\n";
			    echo "Error MySQL: ' . mysql_error()";
   				exit;
					}

  	  			if ($fila = mysqli_fetch_assoc($resultado)) {
				   $claveprivada = $fila['firma'];
				   echo $frm_login;
					}


				mysqli_close($conexion);
		?>
	</body>
</html>