function validar(){
    var nombre,apellido,correo,curp,rfc,firma,direccion,expre1,expre2,expre3;
    nombre = document.getElementById(name1).value;
    apellido = document.getElementById(lastname1).value;
    firma = document.getElementById(Fir).value;
    correo = document.getElementById(correo1).value;
    curp = document.getElementById(CURP).value;
    direccion = document.getElementById(direc).value;
    rfc = document.getElementById(rfc).value;
    expre1 = /\w+@\w+\.+[a-z]/;
    expre2 = /^([A-Z][AEIOUX][A-Z]{2}\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])[HM](?:AS|B[CS]|C[CLMSH]|D[FG]|G[TR]|HG|JC|M[CNS]|N[ETL]|OC|PL|Q[TR]|S[PLR]|T[CSL]|VZ|YN|ZS)[B-DF-HJ-NP-TV-Z]{3}[A-Z\d])(\d)$/;
    expre3 = /^([A-Z,Ñ,&]{3,4}([0-9]{2})(0[1-9]|1[0-2])(0[1-9]|1[0-9]|2[0-9]|3[0-1])[A-Z|\d]{3})$/;

    if(nombre ===""||apellido===""||firma===""||correo===""||curp===""||direccion===""||rfc===""){
        alert("Todos los campos son requeridos para realizar el registro");
        return false;
    }else if(nombre.length>10){
        alert("El nombre es muy largo");
        return false;
    }else if(apellido>15){
        alert("El apellido es muy largo");
        return false;
    }else if(firma>20){
        alert("La firma es muy larga");
        return false;
    }else if(curp===18){
        alert("La curp es incorrecta");
        return false;
    }else if(rfc>13){
        alert("El rfc no es correcto");
        return false;
    }else if(!expre1.test(correo)){
        alert("El correo es incorrecto")
        return false;
    }else if(!expre2.test(curp)){
        alert("La CURP no es correcta")
        return false;
    }else if(!expre3.test(rfc)){
        alert("La CURP no es correcta")
        return false;
    }
}