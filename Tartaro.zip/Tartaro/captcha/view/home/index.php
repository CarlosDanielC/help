<h1 class="page-header text-center">¡Ejemplo de formulario con Captcha!</h1>

<div class="row">
    <div class="col-xs-2"></div>
    <div class="col-xs-8">
        <fieldset>
            <legend class="text-center">Ingrese su comentario</legend>
            
            <form id="frm-comentar" action="?c=Home&a=Procesar" method="post">
                <div class="form-group">
                    <label>Nombre</label>
                    <input type="text" class="form-control" name="Nombre"  data-validacion-tipo="requerido|min:3" />
                </div>
                <div class="form-group">
                    <label>Comentario</label>
                    <textarea class="form-control" name="Comentario"  data-validacion-tipo="requerido|min:10"></textarea>
                </div>
                <div class="form-group">
                    <label>Captcha</label>
                    <input type="text" name="Captcha" class="form-control" data-validacion-tipo="requerido|min:5" maxlength="5" />
                </div>
                <div class="thumbnail">
                    <img id="captcha" src="" />
                </div>
                <button id="btn-comentar" class="btn btn-info btn-lg btn-block" type="submit">Enviar</button>                
            </form>
        </fieldset>
    </div>
</div>

<script>
$(document).ready(function(){
    // Cargamos el captcha
    CargaCaptcha();

    $("#frm-comentar").submit(function(){

        var obj = $(this);

        if(obj.validate()) {
           $.post(obj.attr('action'), obj.serialize(), function(r)
           {
                // En caso de que el captcha no sea correcto, volvemos a cargar
                if(!r.respuesta) 
                {
                    CargaCaptcha();
                }
                else 
                {
                    obj.html('<div class="alert alert-info text-center">¡Su comentario ha sido enviado con éxito!</div>');
                }

           }, 'json')                
        }

        return false;
    });
})
        
function CargaCaptcha()
{
    var d = new Date();
    $("#captcha").attr('src', '?c=Captcha&' + d.getTime());
}
</script>