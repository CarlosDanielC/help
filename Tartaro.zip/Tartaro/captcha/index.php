<?php
session_start();

// Todo esta lógica hara el papel de un FrontController
if(!isset($_REQUEST['c'])){
    // Controlador por defecto
    require_once 'controller/home.controller.php';
    $controller = new HomeController();
    $controller->Index();    
} else {
    
    // Obtenemos el controlador que queremos cargar
    require_once 'controller/' . strtolower($_REQUEST['c']) . '.controller.php';
    $controller = $_REQUEST['c'] . 'Controller';
    $accion     = isset($_REQUEST['a']) ? $_REQUEST['a'] : 'Index';
    
    
    // Instanciamos el controlador
    $controller = new $controller();
    
    // Llama la accion
    call_user_func( array( $controller, $accion ) );
}