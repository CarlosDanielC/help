<!DOCTYPE html>

<!--	recibir.php

Cifrado de datos de un formulario con JavaScript

Este codigo descifra lo que envio el archivo index.html
La forma de descifrado es nuevamente invertir las cadenas que llegaron

xumarhu.net - Rogelio Ferreira Escutia - Mayo 2012

-->

<html>
	<head>
		<title>Cifrado de datos de un formulario con JavaScript</title>
		<meta charset="utf-8" />
	</head>
	<body>
		<h2>Cifrado de datos de un formulario con JavaScript</h2>
		<?PHP
			extract($_REQUEST, EXTR_PREFIX_ALL|EXTR_REFS, 'frm');
			echo "DATOS RECIBIDOS CIFRADOS<br />";
			echo "<br />Login: ".$frm_login;
			echo "<br />Password: ".$frm_password;
			$cadena_invertida="";
			for($i=strlen($frm_login);$i>0;$i--)
				$cadena_invertida .= substr($frm_login,$i-1,1);
				$frm_login=$cadena_invertida;
				$cadena_invertida="";
			for($i=strlen($frm_password);$i>0;$i--)
				$cadena_invertida .= substr($frm_password,$i-1,1);
				$frm_password=$cadena_invertida;
			echo "<br /><br />DATOS DESCIFRADOS<br />";
			echo "<br />Login: ".$frm_login;
			echo "<br />Password: ".$frm_password;
		?>
	</body>
</html>