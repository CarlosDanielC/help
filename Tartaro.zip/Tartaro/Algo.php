<?php
    $persona = [
        "Nombre" => "John Doe",
        "Descripcion" => "Cliente"
    ];
    $datosCodi = json_encode($persona);
    $url = "localhost/json/recibir.php";
    $ch = curl_init($url);
    curl_setopt_array($ch, array(
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $datosCodi,
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json',
            'content-Length: ' . strlen($datosCodi)
        ),
        CURLOPT_RETURNTRANSFER => true
    ));
    $resultado = curl_exec($ch);
    $codigoRes = curl_getinfo($ch, CURLOPT_HTTP_CODE);
    if($codigoRes == 200){
        $resDecof = json_decode($resultado);
        echo "<br><strong>Datos que regresó el Servidor:</strong></br>";
        echo "<br>Nombre: " . $resDecof->nombre;
        echo "<br>Certificado: " . $resDecof->certificado;
    }else{
        echo "Error, Los monos del servidor han mandado - " . $codigoRes;
    }
    curl_close($ch);