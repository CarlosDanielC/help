<?php

    $datosR = file_get_contents("php://input");
    $persona = json_decode($datosR);
    $nombreP = $persona->nombre;
    $DescP = $persona->desc;
    $cert = "kt890nAP34se";
    $resp = [
        "nombre" => $nombreP,
        "Certificado" => $cert
    ];
    $respC = json_encode($resp);
    echo $respC;



?>